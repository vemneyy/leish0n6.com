import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.types import BotCommand

from bot.handlers.usermode import register_usermode_handlers
from bot.handlers.adminmode import register_admin_handlers


logger = logging.getLogger(__name__)

BOT_TOKEN = "1903210448:AAGnWi-DQx1c-sp8quy0ozo1M3mmwU8ThTU"
CHAT_ID = "779425329"

async def set_bot_commands(bot: Bot):
    commands = [
        BotCommand(command="help", description="Help on using the bot"),
        BotCommand(command="currencies", description="Getting the exchange rate of the top 5 currencies"),
        BotCommand(command="cryptocurrencies", description="Getting the course of the top 5 cryptocurrencies"),
    ]
    await bot.set_my_commands(commands)


async def main():
    # Настройка логирования в stdout
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
    )

    # Объявление и инициализация объектов бота и диспетчера,
    # а также извлечение переменных окружения с приведением к нужным типам
    token = BOT_TOKEN
    if not token:
        raise ValueError("Не указан токен. Бот не может быть запущен.")

    admin_chat_id = CHAT_ID
    if not admin_chat_id:
        raise ValueError("Не указан идентификатор чата для пересылки сообщений. Бот не может быть запущен.")
    try:
        admin_chat_id = int(admin_chat_id)
    except ValueError:
        raise ValueError(f'Идентификатор "{admin_chat_id}" не является числом. Бот не может быть запущен.')

    bot = Bot(token=token)
    dp = Dispatcher(bot)

    # Регистрация хэндлеров
    register_admin_handlers(dp, admin_chat_id)
    register_usermode_handlers(dp)

    # Регистрация /-команд в интерфейсе
    await set_bot_commands(bot)

    logger.info("Starting bot")

    # Запуск поллинга
    await dp.start_polling()


if __name__ == '__main__':
    try:
        asyncio.run(main())
    except ValueError as ex:
        logger.error(ex)
        exit(1)
