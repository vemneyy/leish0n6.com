from asyncio import sleep
from aiogram import Dispatcher, types, bot
import requests
import time
from bs4 import BeautifulSoup

global headers
headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}



class currencies_pages:
    global USD
    USD = 'https://www.profinance.ru/currency_usd.asp'
    global EUR
    EUR = 'https://www.profinance.ru/currency_eur.asp'
    global JPY
    JPY = 'https://finance.yahoo.com/quote/JPYRUB=X/'
    global GBP
    GBP = 'https://finance.yahoo.com/quote/gbprub=x/'
    global AUD
    AUD = 'https://finance.yahoo.com/quote/AUDRUB=X/'


class cryptocurrencies:
    global BTC
    BTC = 'https://finance.yahoo.com/quote/BTC-USD'
    global ETH
    ETH = 'https://finance.yahoo.com/quote/ETH-USD'
    global ADA
    ADA = 'https://finance.yahoo.com/quote/ADA-USD'
    global DOGE
    DOGE = 'https://finance.yahoo.com/quote/DOGE-USD'
    global XMR
    XMR = 'https://finance.yahoo.com/quote/XMR-USD'


def get_usd():
    page_usd = requests.get(USD, headers=headers)
    soup_usd = BeautifulSoup(page_usd.content, 'html.parser')
    convert_usd = soup_usd.findAll('font', {'color': 'Red'})
    res_usd = convert_usd[3].text
    global final_usd
    final_usd = str(res_usd)


def get_eur():
    page_eur = requests.get(EUR, headers=headers)
    soup_eur = BeautifulSoup(page_eur.content, 'html.parser')
    convert_eur = soup_eur.findAll('font', {'color': 'Red'})
    res_eur = convert_eur[3].text
    global final_eur
    final_eur = str(res_eur)


def get_jpy():
    page_jpy = requests.get(JPY, headers=headers)
    soup_jpy = BeautifulSoup(page_jpy.content, 'html.parser')
    convert_jpy = soup_jpy.findAll('span', {'class': 'Trsdu(0.3s) Fw(b) Fz(36px) Mb(-4px) D(ib)'})
    res_jpy = convert_jpy[0].text
    global final_jpy
    final_jpy = str(res_jpy)


def get_gbp():
    page_gbp = requests.get(GBP, headers=headers)
    soup_gbp = BeautifulSoup(page_gbp.content, 'html.parser')
    convert_gbp = soup_gbp.findAll('span', {'class': 'Trsdu(0.3s) Fw(b) Fz(36px) Mb(-4px) D(ib)'})
    res_gbp = convert_gbp[0].text
    global final_gbp
    final_gbp = str(res_gbp)


def get_aud():
    page_aud = requests.get(AUD, headers=headers)
    soup_aud = BeautifulSoup(page_aud.content, 'html.parser')
    convert_aud = soup_aud.findAll('span', {'class': 'Trsdu(0.3s) Fw(b) Fz(36px) Mb(-4px) D(ib)'})
    res_aud = convert_aud[0].text
    global final_aud
    final_aud = str(res_aud)


def get_btc():
    page_btc = requests.get(BTC, headers=headers)
    soup_btc = BeautifulSoup(page_btc.content, 'html.parser')
    convert_btc = soup_btc.findAll('span', {'class': 'Trsdu(0.3s) Fw(b) Fz(36px) Mb(-4px) D(ib)'})
    res_btc = convert_btc[0].text
    global final_btc
    final_btc = str(res_btc)


def get_eth():
    page_eth = requests.get(ETH, headers=headers)
    soup_eth = BeautifulSoup(page_eth.content, 'html.parser')
    convert_eth = soup_eth.findAll('span', {'class': 'Trsdu(0.3s) Fw(b) Fz(36px) Mb(-4px) D(ib)'})
    res_eth = convert_eth[0].text
    global final_eth
    final_eth = str(res_eth)


def get_ada():
    page_ada = requests.get(ADA, headers=headers)
    soup_ada = BeautifulSoup(page_ada.content, 'html.parser')
    convert_ada = soup_ada.findAll('span', {'class': 'Trsdu(0.3s) Fw(b) Fz(36px) Mb(-4px) D(ib)'})
    res_ada = convert_ada[0].text
    global final_ada
    final_ada = str(res_ada)


def get_doge():
    page_doge = requests.get(DOGE, headers=headers)
    soup_doge = BeautifulSoup(page_doge.content, 'html.parser')
    convert_doge = soup_doge.findAll('span', {'class': 'Trsdu(0.3s) Fw(b) Fz(36px) Mb(-4px) D(ib)'})
    res_doge = convert_doge[0].text
    global final_doge
    final_doge = str(res_doge)


def get_xmr():
    page_xmr = requests.get(XMR, headers=headers)
    soup_xmr = BeautifulSoup(page_xmr.content, 'html.parser')
    convert_xmr = soup_xmr.findAll('span', {'class': 'Trsdu(0.3s) Fw(b) Fz(36px) Mb(-4px) D(ib)'})
    res_xmr = convert_xmr[0].text
    global final_xmr
    final_xmr = str(res_xmr)


async def cmd_start_admin(message: types.Message):
    """
    Приветственное сообщение от бота пользователю

    :param message: сообщение от пользователя с командой /start
    """
    await message.answer(
        'HI!\nWith the help of this bot, you can find out the exchange rate of the top 5 currencies of the world, as well as the top 5 cryptocurrencies of the world')


async def cmd_help_admin(message: types.Message):
    """
    Справка для пользователя

    :param message: сообщение от пользователя с командой /help
    """
    await message.answer(
        "To find out the rate of the top 5 currencies of the world-enter the command /currencies\n\nTo find out the rate of the top 5 cryptocurrencies of the world-enter the command /cryptocurrencies")


async def currencies_admin(message: types.Message):
    msg = await message.reply("Сurrency exchange rates are loaded!")
    await sleep(0.1)

    get_usd()
    get_eur()
    get_jpy()
    get_gbp()
    get_aud()

    await msg.delete()
    final_message = str(
        'TOP 5 Currencies:' '\n\nUSD (United States Dollar): ' + final_usd + ' ₽\n\n' + 'EUR (Euro): ' + final_eur + ' ₽\n\n' + 'JPY (Japanese Yen): ' + final_jpy + ' ₽\n\n' + 'GBP (Pound sterling): ' + final_gbp + ' ₽\n\n' + 'AUD (Australian Dollar): ' + final_aud + ' ₽')

    await message.answer(final_message, parse_mode="HTML")


async def cryptocurrencies_admin(message: types.Message):
    msg = await message.reply("Сryptocurrency exchange rates are loaded!")
    await sleep(0.1)

    get_btc()
    get_eth()
    get_ada()
    get_doge()
    get_xmr()

    await msg.delete()
    final_message = str(
        'TOP 5 Сryptocurrencies:' '\n\nBTC (Bitcoin): ' + final_btc + ' $\n\n' + 'ETH (Ethereum): ' + final_eth + ' $\n\n' + 'ADA (Cardano): ' + final_ada + ' $\n\n' + 'DOGE (Dogecoin): ' + final_doge + ' $\n\n' + 'XMR (Monero): ' + final_xmr + ' $')

    await message.answer(final_message, parse_mode="HTML")

# def check_currency(self):
# 		currency = float(self.get_currency_price().replace(",", "."))
# 		if currency >= self.current_converted_price + 1000:
# 			print("Курс сильно вырос, может пора что-то делать?")
# 			self.send_mail()
# 		elif currency <= self.current_converted_price - 1000:
# 			print("Курс сильно упал, может пора что-то делать?")
# 			self.send_mail()
#
# 		print("Сейчас курс: 1 доллар = " + str(currency))
# 		time.sleep(3) # Засыпание программы на 3 секунды
# 		self.check_currency()



def register_admin_handlers(dp: Dispatcher, admin_chat_id: int):
    dp.register_message_handler(cmd_start_admin, commands="start")
    dp.register_message_handler(cmd_help_admin, commands="help")
    dp.register_message_handler(cryptocurrencies_admin, commands="cryptocurrencies")
    dp.register_message_handler(currencies_admin, commands="currencies")